export const FETCH_DOC_REQUESTED = 'documents/FETCH_DOC_REQUESTED';
export const FETCH_DOC_SUCCESS = 'documents/FETCH_DOC_SUCCESS';
export const FETCH_DOC_FAILURE = 'documents/FETCH_DOC_FAILURE';

export const CREATE_DOC_REQUESTED = 'documents/CREATE_DOC_REQUESTED';
export const CREATE_DOC_SUCCESS = 'documents/CREATE_DOC_SUCCESS';
export const CREATE_DOC_FAILURE = 'documents/CREATE_DOC_FAILURE';
