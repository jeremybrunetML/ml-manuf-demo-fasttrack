export const defaultValues = [
  {
    name: 'First',
    value: 'First',
    count: 100
  },
  {
    name: 'Second',
    value: 'Second',
    count: 55
  },
  {
    name: 'Third',
    value: 'Third',
    count: 75
  }
];
